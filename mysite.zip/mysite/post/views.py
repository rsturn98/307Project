from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from . import forms

@login_required
def post(request):
    context = {'posts': request.user.post_set.all()}
    if request.method == 'POST':
        form = forms.PostForm(request.POST)
        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.owner = request.user
            new_post.save()
        context['form'] = form
    return render(request, 'post/post.html', context)


